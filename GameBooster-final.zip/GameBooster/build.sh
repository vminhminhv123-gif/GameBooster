#!/bin/bash

# GameBooster - Build Script for Termux
# Tự động build APK với các tùy chọn

echo "=========================================="
echo "GameBooster - Build Script"
echo "=========================================="
echo ""

# Kiểm tra nếu gradlew tồn tại
if [ ! -f "gradlew" ]; then
    echo "❌ Không tìm thấy gradlew!"
    echo "Vui lòng chạy script này từ thư mục GameBooster"
    exit 1
fi

# Menu
echo "Chọn loại build:"
echo "1) Debug APK (nhanh, cho test)"
echo "2) Release APK (tối ưu, cho phân phối)"
echo "3) Clean build (xóa cache rồi build)"
echo ""
read -p "Nhập lựa chọn (1-3): " choice

case $choice in
    1)
        echo ""
        echo "🏗️ Building Debug APK..."
        echo ""
        chmod +x ./gradlew
        ./gradlew assembleDebug
        
        if [ $? -eq 0 ]; then
            echo ""
            echo "✅ Build thành công!"
            echo ""
            echo "📦 APK nằm tại:"
            echo "   app/build/outputs/apk/debug/app-debug.apk"
            echo ""
            echo "💾 Copy sang Downloads?"
            read -p "Nhập y/n: " copy_choice
            if [ "$copy_choice" = "y" ]; then
                cp app/build/outputs/apk/debug/app-debug.apk ~/storage/downloads/
                echo "✅ Đã copy sang Downloads"
            fi
        else
            echo ""
            echo "❌ Build thất bại!"
            exit 1
        fi
        ;;
    2)
        echo ""
        echo "🏗️ Building Release APK..."
        echo ""
        chmod +x ./gradlew
        ./gradlew assembleRelease
        
        if [ $? -eq 0 ]; then
            echo ""
            echo "✅ Build thành công!"
            echo ""
            echo "📦 APK nằm tại:"
            echo "   app/build/outputs/apk/release/app-release.apk"
            echo ""
            echo "💾 Copy sang Downloads?"
            read -p "Nhập y/n: " copy_choice
            if [ "$copy_choice" = "y" ]; then
                cp app/build/outputs/apk/release/app-release.apk ~/storage/downloads/
                echo "✅ Đã copy sang Downloads"
            fi
        else
            echo ""
            echo "❌ Build thất bại!"
            exit 1
        fi
        ;;
    3)
        echo ""
        echo "🧹 Cleaning project..."
        chmod +x ./gradlew
        ./gradlew clean
        
        echo ""
        echo "🏗️ Building Debug APK..."
        ./gradlew assembleDebug
        
        if [ $? -eq 0 ]; then
            echo ""
            echo "✅ Build thành công!"
            echo ""
            echo "📦 APK nằm tại:"
            echo "   app/build/outputs/apk/debug/app-debug.apk"
        else
            echo ""
            echo "❌ Build thất bại!"
            exit 1
        fi
        ;;
    *)
        echo "❌ Lựa chọn không hợp lệ!"
        exit 1
        ;;
esac

echo ""
echo "=========================================="
echo "✅ Hoàn thành!"
echo "=========================================="
